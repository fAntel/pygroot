__all__ = ["NAME", "VERSION"]

NAME = "pygroot"
VERSION = "1.0"
